import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/statemgt/screen1.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';

// ignore: must_be_immutable
class Screen2 extends StatefulWidget {
  Screen2({super.key, required this.counter});
  int counter;
  @override
  State<Screen2> createState() => _screen1State();
}

class _screen1State extends State<Screen2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Customtext(
              "Screen two",
              fontsize: 20,
            ),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  setState(() {
                    widget.counter++;
                  });
                },
                text: "Add+"),
            SizedBox(
              height: 20,
            ),
            Customtext(widget.counter.toString()),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  setState(() {
                    widget.counter--;
                  });
                },
                text: "Sub-"),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  Helpers.navigateTo(context, Screen1());
                },
                text: "Previos Button")
          ],
        ),
      ),
    );
  }
}
