import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/statemgt/screen2.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';

class Screen1 extends StatefulWidget {
  const Screen1({super.key});

  @override
  State<Screen1> createState() => _screen1State();
}

class _screen1State extends State<Screen1> {
  int _counter = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Customtext(
              "Screen One",
              fontsize: 20,
            ),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  setState(() {
                    _counter++;
                  });
                },
                text: "Add+"),
            SizedBox(
              height: 20,
            ),
            Customtext("$_counter"),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  setState(() {
                    _counter--;
                  });
                },
                text: "Sub-"),
            SizedBox(
              height: 20,
            ),
            Button(
                ontap: () {
                  Helpers.navigateTo(
                      context,
                      Screen2(
                        counter: _counter,
                      ));
                },
                text: "Next Button")
          ],
        ),
      ),
    );
  }
}
