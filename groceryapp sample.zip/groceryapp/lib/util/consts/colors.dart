import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xff0FA956);
  static const ash = Color(0xff9B9B9B);
  static const darkgreen = Color(0xff2E6C00);
}
