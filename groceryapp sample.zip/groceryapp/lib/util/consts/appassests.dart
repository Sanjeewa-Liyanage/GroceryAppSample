class Appassets {
  static String logo = "assets/icons/logo.png";
  static const String dialog = "assets/images/dialog-img.svg";
  static const String google = "assets/icons/google.svg";
  static const String fb = "assets/icons/fb.svg";
  static const String menuicon = "assets/icons/menu-icon.svg";
  static const String cart = "assets/icons/cart-icon.svg";
  static const String dumyimg2 =
      "https://www.farmersalmanac.com/wp-content/uploads/2020/11/Planting-Guide-Tomatoes-A118789228.jpg";
  static const String dumyimg =
      "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRemk0pOj3avWb06RvabQarkPJ-BUaZPIT9UjLWrwM6xL8TyRbj";
  static const String dumyprofile =
      "https://static.vecteezy.com/system/resources/previews/000/439/863/original/vector-users-icon.jpg";
}
