import 'dart:io';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/file_upload_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/models/user_model.dart';

import 'package:groceryapp/util/consts/appassests.dart';
import 'package:logger/logger.dart';

class AuthController {
  //Signup user fun//
  Future<void> SignupUser(BuildContext context, String loginemail,
      String loginpassword, String name) async {
    try {
      //--send the email and password to the firebase and try to create a user --//
      final credential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: loginemail,
        password: loginpassword,
      );

      Logger().i(credential.user);
      if (credential.user != null) {
        Logger().i("User created success");
        //if success save extra user data
        SaveUserData(loginemail, name, credential.user!.uid);
      } else {
        Logger().i("User not created");
      }
    } on FirebaseAuthException catch (e) {
      AlertHelper.showAlert(context, e.code, e.code);
    } catch (e) {
      AlertHelper.showAlert(context, e.toString(), e.toString());
    }
  }

  CollectionReference users = FirebaseFirestore.instance.collection('users');

  //save extra details of user
//create a collection reference called users
  Future<void> SaveUserData(String email, String name, String uid) async {
    return users
        .doc(uid)
        .set({
          'uid': uid,
          'email': email,
          'name': name,
          'img': Appassets.dumyprofile,
          // 42
        })
        .then((value) => Logger().i("$email,$name,$uid"))
        .catchError((error) => Logger().e("Failed to add user: $error"));
  }

//login user to Application
  Future<void> Logintosystem(
      BuildContext context, String email, String password) async {
    try {
      //login to system
      // start the loader

      await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password)
          .then((credential) {
        Logger().i(credential);
        // Helpers.navigateTo(context, MainScreen());
      });
    } on FirebaseAuthException catch (e) {
      print("Firebase auth exception ${e.message}");
      AlertHelper.showAlert(context, e.code, "Invalid Email or Password");
    } catch (e) {
      AlertHelper.showAlert(context, e.toString(), "Err");
    }
  }

  //send password reset email
  Future<void> Sendemail(
    BuildContext context,
    String email,
  ) async {
    try {
      //login to system
      // start the loader

      await FirebaseAuth.instance
          .sendPasswordResetEmail(
        email: email,
      )
          .then((value) {
        AlertHelper.showAlert(
            context, "Password reset", "Email sent check your inbox",
            type: DialogType.success);
      });
    } on FirebaseAuthException catch (e) {
      print("Firebase auth exception ${e.message}");
      AlertHelper.showAlert(context, e.code, "Invalid Email");
    } catch (e) {
      AlertHelper.showAlert(context, e.toString(), "Err");
    }
  }

  //fetch user data from cloud  firestore
  Future<UserModel?> FetchUserData(
    BuildContext context,
    String uid,
  ) async {
    try {
      //fire base quary that find and fetch user data according to uid
      DocumentSnapshot documentSnapshot = await users.doc(uid).get();
      if (documentSnapshot.exists) {
        Logger().w(documentSnapshot.data());
        //Mapping fetch data to user model
        UserModel model =
            UserModel.fromJson(documentSnapshot.data() as Map<String, dynamic>);
        return model;
      } else {
        Logger().e("No data found");
        return null;
      }
    } catch (e) {
      Logger().e(e);
    }
  }
  //file upload controller object

  final FileUploadController _fileUploadController = FileUploadController();

// upload the image file to firebase storage and then update the download url in users data

  Future<String> UploadAndUpdateProfileImg(File file, String uid) async {
    try {
      //start file uploading
      final String downloadUrl =
          await _fileUploadController.Uploadfile(file, "userImages");
      //chek if the download url is empty or not
      if (downloadUrl != "") {
        //update the field of the current user data
        await users.doc(uid).update({
          "img": downloadUrl,
        });
        return downloadUrl;
      } else {
        Logger().e("Download url is empty");
        return "";
      }
    } catch (e) {
      Logger().e(e);
      return "";
    }
  }
}

/// await FireBAseAuth.instance.createUserWithEmailAndPassword{
/// email:email,
/// password: password
/// }. then((credential){
/// if (credential.user != null) {}
/// });
/// this is the second method to do this!!!!!!!!!--//
