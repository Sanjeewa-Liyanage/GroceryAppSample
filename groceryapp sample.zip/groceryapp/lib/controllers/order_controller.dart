import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/order_model.dart';
import 'package:groceryapp/models/user_model.dart';
import 'package:logger/logger.dart';

class OrderController {
  //create a order collection
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  CollectionReference orders = FirebaseFirestore.instance.collection('orders');

  Future<String> SaveOrder(
      UserModel user, double total, List<CartItemModel> items) async {
    String id = orders.doc().id;
    //temporary list
    var List = [];
    //read the cart items list and add items to a dynamic list
    //beacouse we can only store dynamic type arrays in firestore
    for (var i = 0; i < items.length; i++) {
      List.add(items[i].toJson());
    }
    return orders.doc(id).set({
      'id': id,
      'user': user.toJson(),
      'total': total,
      'items': List,
      'orderStatus': "pending",

      // 42
    }).then((value) {
      Logger().i("order created");
      return "Success";
    }).catchError((error) {
      Logger().e("Failed add order: $error");
      return "$error";
    });
  }

  Future<List<OrderModel>> fetchOrderList(String uid) async {
    try {
      // fire base query find and fetch product list
      QuerySnapshot documentSnapshot =
          await orders.where("user.uid", isEqualTo: uid).get();

      Logger().w(documentSnapshot.docs.length);

      //product list
      List<OrderModel> orderlist = [];

      if (documentSnapshot.docs.isNotEmpty) {
        for (var e in documentSnapshot.docs) {
          OrderModel model =
              OrderModel.fromJson(e.data() as Map<String, dynamic>);
          orderlist.add(model);
        }

        return orderlist;
      } else {
        return [];
      }
    } catch (e) {
      Logger().e(e);
      return [];
    }
  }
}
