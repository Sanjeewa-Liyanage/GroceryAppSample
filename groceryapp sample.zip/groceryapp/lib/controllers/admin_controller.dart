import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:groceryapp/controllers/file_upload_controller.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:logger/logger.dart';

class AdminController {
  CollectionReference products =
      FirebaseFirestore.instance.collection('products');

  /// file upload controller
  ///
  final FileUploadController _fileUploadController = FileUploadController();

  Future<void> SaveProductData(String productName, String productDescription,
      String price, File file) async {
    /// first upload the file and get download url  to product image

    final String downloadurl =
        await _fileUploadController.Uploadfile(file, 'productImages');
    if (downloadurl != "") {
      //--- getting a unque id

      String id = products.doc().id;

      return products
          .add({
            'id': id,
            'productName': productName,
            'desc': productDescription,
            'price': price,
            'img': downloadurl,
            // 42
          })
          .then((value) => Logger()
              .i("$id,$productName,$productDescription,$price,$downloadurl"))
          .catchError((error) => Logger().e("Failed to add user: $error"));
    }
  }

  //fetch product data from cloud firestore

  Future<List<ProductModel>> fetchProductList() async {
    try {
      // fire base query find and fetch product list
      QuerySnapshot querySnapshot = await products.get();

      Logger().w(querySnapshot.docs.length);

      //product list
      List<ProductModel> productlist = [];

      for (var e in querySnapshot.docs) {
        //mapping to product model

        ProductModel model =
            ProductModel.fromJson(e.data() as Map<String, dynamic>);
//- adding to the list
        productlist.add(model);
      }

      return productlist;
    } catch (e) {
      Logger().e(e);
      return [];
    }
  }
}
