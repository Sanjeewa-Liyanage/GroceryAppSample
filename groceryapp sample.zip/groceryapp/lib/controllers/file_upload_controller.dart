import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart';
import 'package:logger/logger.dart';

class FileUploadController {
  //--Upload picked image file to the firebase storage bucket in the to given path

  Future<String> Uploadfile(File file, String folderpath) async {
    try {
      //get in the file name from the file path

      final String filename = basename(file.path);
      // defining the firebase storage destination where the file should be uploaded to
      final String destination = "$folderpath/$filename";

      // creating the firebase storage  reference with the destination file location

      final ref = FirebaseStorage.instance.ref(destination);

      // uploading the file

      final UploadTask task = ref.putFile(file);

      //wait until  the file is completely uploaded and then print a success(task is completed)

      final snapshot = await task.whenComplete(() {});

      //getting the download url of the uploaded file
      final String downloadurl = await snapshot.ref.getDownloadURL();
      return downloadurl;
    } catch (e) {
      Logger().e(e);
      return "";
    }
  }
}
