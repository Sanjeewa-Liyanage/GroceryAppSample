//order model
//user model
//order total
//order items list
//order status
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/models/user_model.dart';

class OrderModel {
  String id;
  UserModel user;
  double total;
  List<CartItemModel> items;
  String orderStatus;

  OrderModel({
    required this.id,
    required this.user,
    required this.items,
    required this.total,
    required this.orderStatus,
  });

  OrderModel.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        user = UserModel.fromJson(json['user'] as Map<String, dynamic>),
        total = (json['total'] as num).toDouble(),
        items = (json['items'] as List<dynamic>)
            .map((e) => CartItemModel.fromJson(e as Map<String, dynamic>))
            .toList(),
        orderStatus = json['orderStatus'];
}
