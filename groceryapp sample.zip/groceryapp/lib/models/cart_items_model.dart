// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';
import 'dart:ffi';

import 'package:groceryapp/models/product_model.dart';

class CartItemModel {
  String id;
  int amount;
  double subtotal;
  ProductModel productModel;

  CartItemModel({
    required this.id,
    required this.amount,
    required this.productModel,
    required this.subtotal,
  });

  //bind json data t cartitem model

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'amount': amount,
      'subtotal': subtotal,
      'productModel': productModel.toJson(),
    };
  }

  CartItemModel.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        amount = (json['amount'] as num).toInt(),
        subtotal = (json['subtotal'] as num).toDouble(),
        productModel =
            ProductModel.fromJson(json['productModel'] as Map<String, dynamic>);
}
