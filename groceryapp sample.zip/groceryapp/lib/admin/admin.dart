import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/providers/admin/admin_provider.dart';

import 'package:groceryapp/util/consts/colors.dart';

import 'package:groceryapp/widgets/backbutton.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/textfield.dart';
import 'package:provider/provider.dart';

class Admin extends StatefulWidget {
  const Admin({Key? key}) : super(key: key);

  @override
  State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(alignment: Alignment.centerLeft, child: Back()),
                  SizedBox(
                    height: 28,
                  ),
                  const Customtext(
                    "Admin Section",
                    color: AppColors.primaryColor,
                    fontsize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                  const SizedBox(
                    height: 41,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  CustomTextField(
                    hint: 'Enter Product Name',
                    label: "Product Name",
                    controller: Provider.of<AdminProvider>(context).pname,
                  ),
                  const SizedBox(
                    height: 7,
                  ),
                  CustomTextField(
                    hint: "Enter Product description",
                    label: "Description",
                    controller: Provider.of<AdminProvider>(context).pdesc,
                  ),
                  const SizedBox(
                    height: 7,
                  ),
                  CustomTextField(
                    hint: "Product Price",
                    label: "Price",
                    controller: Provider.of<AdminProvider>(context).price,
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  Consumer<AdminProvider>(
                    builder: (BuildContext context, value, Widget? child) {
                      return value.pimage.path == ""
                          ? IconButton(
                              onPressed: () {
                                value.selectProductImage(context);
                              },
                              icon: Icon(
                                Icons.photo_library,
                                size: 50,
                              ))
                          : InkWell(
                              onTap: () => value.selectProductImage(context),
                              child: Image.file(
                                value.pimage,
                                width: 200,
                                height: 200,
                              ),
                            );
                    },
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  Consumer<AdminProvider>(
                    builder: (context, value, child) {
                      return Button(
                        isLoading: value.isLoading,
                        text: "Save Product",
                        ontap: () {
                          value.startSaveProductData(context);
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
