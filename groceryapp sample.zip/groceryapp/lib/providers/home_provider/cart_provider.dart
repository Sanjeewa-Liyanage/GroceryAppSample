import 'package:animated_snack_bar/animated_snack_bar.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/screens/main/cart/cart.dart';
import 'package:logger/logger.dart';

class cartProvider extends ChangeNotifier {
  //cart counter section

  int _counter = 1;
  int get counter => _counter;
  // increase cart counter

  void increaseCounter() {
    _counter++;
    notifyListeners();
  }

  void decreaseCounter() {
    if (_counter != 1) {
      _counter--;
      notifyListeners();
    }
  }

//clear the amount
  void clearCounter() {
    _counter = 1;
    notifyListeners();
  }

  //add to cart
//cart item list
  List<CartItemModel> _cartitems = [];
  List<CartItemModel> get cartitems => _cartitems;

  //initializeadd to cart funcinality

  void AddtoCart(ProductModel model, BuildContext context) {
    //first check weather adding product is already in the cart item list
    if (_cartitems.any((e) => e.id == model.id)) {
      //-----if exist increase the product amount of the exsisting cart item
// find the exsisiting cart item
      var temp = _cartitems.singleWhere((e) => e.id == model.id);
      //update the amount
      temp.amount += _counter;
      //calculate the subtotal according to the new amount
      temp.subtotal = temp.amount * double.parse(model.price);
      notifyListeners();
      clearCounter();

      AlertHelper.showSnackBar(
          context, "Increased the amount of ${model.productName}",
          type: AnimatedSnackBarType.success);
    } else {
//------adding items to cart
      _cartitems.add(CartItemModel(
        amount: _counter,
        id: model.id,
        productModel: model,
        subtotal: _counter * double.parse(model.price),
      ));
      clearCounter();
      Logger().i(_cartitems.length);
      AlertHelper.showSnackBar(
          context, "Successfuly Added t ${model.productName} to the Car",
          type: AnimatedSnackBarType.success);
      notifyListeners();
    }

    //ading items to cart
  }

  //---- calculate and get total cart items count
  int get getCartTotalItemCount {
    int temp = 0;
//reading the cart item list and get the sum of amount values as the cart item count
    for (var i = 0; i < _cartitems.length; i++) {
      temp += _cartitems[i].amount;
    }
    return temp;
  }

//calculate and get total
  double get getCartTotalPrice {
    double temptotal = 0;
//reading the cart item list and get the sum of subtotal values as the cart item count
    for (var i = 0; i < _cartitems.length; i++) {
      temptotal += _cartitems[i].subtotal;
    }
    return temptotal;
  }

  //increase the cart item amount

  void increaseCartItemAmount(String cartid) {
    // find the exsisiting cart item
    var temp = _cartitems.singleWhere((e) => e.id == cartid);
    //update the amount
    temp.amount++;
    //calculate the subtotal according to the new amount
    temp.subtotal = temp.amount * double.parse(temp.productModel.price);
    notifyListeners();
  }

  void decreaseCartItemAmount(String cartid) {
    // find the exsisiting cart item
    var temp = _cartitems.singleWhere((e) => e.id == cartid);
    //update the amount
    if (temp.amount == 1) {
      // when amount zero io remove it from the list
      RemoveCartItem(cartid);
    } else {
      temp.amount--;
      //calculate the subtotal according to the new amount
      temp.subtotal = temp.amount * double.parse(temp.productModel.price);
      notifyListeners();
    }
  }

//remove item
  void RemoveCartItem(String cartid) {
    var temp = _cartitems.removeWhere((e) => e.id == cartid);
    notifyListeners();
  }
}
