import 'package:animated_snack_bar/animated_snack_bar.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/admin_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:logger/logger.dart';

class ProductProvider extends ChangeNotifier {
  final AdminController _adminController = AdminController();
  //Loader state //

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  List<ProductModel> _products = [];
  List<ProductModel> get products => _products;

  Future<void> StartFetchProducts() async {
    try {
      //start the loader

      setLoading(true);
      await _adminController.fetchProductList().then((value) {
        _products = value;
        notifyListeners();
        setLoading(false);
      });
    } catch (e) {
      Logger().e("${e}");
      setLoading(false);
    }
  }
  // product details section
  // to store the selected product model

  late ProductModel _productModel;
  // get the selected product model
  ProductModel get productModel => _productModel;
  //set the selected product model when click on the product card

  set setProduct(ProductModel model) {
    _productModel = model;
    notifyListeners();
  }

  //get related products excluding the selected products
  List<ProductModel> get relatedproducts {
    List<ProductModel> temp = [];
    //reading without already selected product
    for (var i = 0; i < _products.length; i++) {
      if (_products[i].id != productModel.id) {
        temp.add(_products[i]);
      }
    }
    return temp;
  }

  //add to favourites

  // to store favourite products

  List<ProductModel> _favProducts = [];
  //get fav products
  List<ProductModel> get favProduts => _favProducts;

  // add to favmethod

  void AddtoFav(ProductModel model, BuildContext context) {
    //first check weather this product is already in the list

    if (_favProducts.contains(model)) {
      //if exsist , remove that product from the fav list

      _favProducts.remove(model);
      AlertHelper.showSnackBar(
          context, "${model.productName} removed from favourites",
          type: AnimatedSnackBarType.warning);
      notifyListeners();
    } else {
      _favProducts.add(model);

      //show snack bar
      AlertHelper.showSnackBar(
          context, "${model.productName} Added to favourites",
          type: AnimatedSnackBarType.success);
      notifyListeners();
    }
  }
}
