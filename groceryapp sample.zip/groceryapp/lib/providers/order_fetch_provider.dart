import 'package:flutter/cupertino.dart';
import 'package:groceryapp/controllers/order_controller.dart';
import 'package:groceryapp/models/order_model.dart';
import 'package:groceryapp/models/user_model.dart';
import 'package:groceryapp/providers/auth_providers/user_provider.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class OrderFetchProvider extends ChangeNotifier {
  final OrderController _orderController = OrderController();
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  List<OrderModel> _orders = [];
  List<OrderModel> get orders => _orders;

  Future<void> StartFetchOrders(BuildContext context) async {
    try {
      UserModel user =
          Provider.of<UserProvider>(context, listen: false).userModel!;
      //start the loader

      setLoading(true);
      await _orderController.fetchOrderList(user.uid).then((value) {
        _orders = value;
        notifyListeners();
        setLoading(false);
      });
    } catch (e) {
      Logger().e("${e}");
      setLoading(false);
    }
  }
  // product details section
  // to store the selected product model
}
  // add to favmethod

  