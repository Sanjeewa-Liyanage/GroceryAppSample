import 'dart:io';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/admin_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class AdminProvider extends ChangeNotifier {
  final AdminController _adminController = AdminController();

  final TextEditingController _pname = TextEditingController();
  TextEditingController get pname => _pname;

  final TextEditingController _pdesc = TextEditingController();
  TextEditingController get pdesc => _pdesc;

  final TextEditingController _price = TextEditingController();
  TextEditingController get price => _price;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  Future<void> startSaveProductData(BuildContext context) async {
    try {
      setLoading(true);

      await _adminController.SaveProductData(
              _pname.text, _pdesc.text, _price.text, _pimage)
          .then((value) {
        setLoading(false);

        // clear controller

        _pdesc.clear();
        _pname.clear();
        _price.clear();
        _pimage = File("");

        Provider.of<ProductProvider>(context, listen: false)
            .StartFetchProducts();
        AlertHelper.showAlert(
            context, "product added succesfully !!", "Success",
            type: DialogType.success);
      });
    } catch (e) {
      Logger().e(e);
      AlertHelper.showAlert(context, e.toString(), "Error in product adding");
      setLoading(false);
    }
  }

  //-----pick upload and update user profile img

  //image picker instence
  final ImagePicker picker = ImagePicker();

  //file object to store picked
  File _pimage = File("");
  //get pick file
  File get pimage => _pimage;

  // pick an img function
  Future<void> selectProductImage(BuildContext context) async {
    try {
      final XFile? pickfile =
          await picker.pickImage(source: ImageSource.gallery);

      Logger().w(pickfile?.path.toString());

      if (pickfile != null) {
        _pimage = File(pickfile.path);
        notifyListeners();
      } else {
        Logger().e("No img selected");
      }
    } catch (e) {
// check if user has pick file or not

      Logger().e(e);
    }
  }
}
