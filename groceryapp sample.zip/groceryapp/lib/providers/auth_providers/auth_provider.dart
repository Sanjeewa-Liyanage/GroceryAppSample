import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/auth_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/models/user_model.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/screens/main/main_screen.dart';
import 'package:groceryapp/screens/splash/auth/signup.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class AuthProvider extends ChangeNotifier {
  AuthController _authController = AuthController();

  final TextEditingController _username = TextEditingController();
  TextEditingController get username => _username;

  final TextEditingController _email = TextEditingController();
  TextEditingController get email => _email;

  final TextEditingController _password = TextEditingController();
  TextEditingController get password => _password;

  bool validationFields(BuildContext context) {
    if (_username.text.isEmpty ||
        _email.text.isEmpty ||
        _password.text.isEmpty) {
      Logger().w("Fill all the fields");
      AlertHelper.showAlert(
          context, "Fill All text fields", "Data can't be empty");
      return false;
    } else if (!_email.text.contains("@") || (!_email.text.contains(".com"))) {
      Logger().w("Enter valid email");
      AlertHelper.showAlert(
          context, "Email must contain @ & .com", "Invalid email");
      return false;
    } else if (_password.text.length < 8) {
      Logger().w("Enter password at least 8 characters");
      AlertHelper.showAlert(
          context, "Enter password at least 8 characters", "Invalid password");
      return false;
    } else {
      return true;
    }
  }

  //Loader state //

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  Future<void> startSignup(BuildContext context) async {
    try {
      //validating inputs
      if (validationFields(context)) {
        //start creating user
        // start the loader
        setLoading(true);
        await _authController.SignupUser(
                context, _email.text, _password.text, _username.text)
            .then((value) {
          setLoading(false);
          //AlertHelper.showAlert(
          //   context, "User registration success!!", "Signup Success",
          //  type: DialogType.success);
        });
      }
    } catch (e) {
      Logger().e(e);
      AlertHelper.showAlert(context, e.toString(), "Error in SignUp");
      setLoading(false);
    }
  }

  //--Sign out

  Future<void> Logout() async {
    await FirebaseAuth.instance.signOut();
  }

//---login user feature

  final TextEditingController _loginemail = TextEditingController();
  TextEditingController get loginemail => _loginemail;

  final TextEditingController _loginpassword = TextEditingController();
  TextEditingController get loginpassword => _loginpassword;

  Future<void> startLogin(BuildContext context) async {
    try {
      //validating inputs
      if (validationFieldsLogin(context)) {
        //start creating user
        // start the loader
        setLoading(true);
        await _authController.Logintosystem(
          context,
          _loginemail.text,
          _loginpassword.text,
        ).then((value) {
          setLoading(false);

          // clear controller

          _loginemail.clear();

          _loginpassword.clear();
          setLoading(false); //AlertHelper.showAlert(
          //   context, "User registration success!!", "Signup Success",
          //  type: DialogType.success);
        });
      }
    } catch (e) {
      Logger().e(e);
      AlertHelper.showAlert(context, e.toString(), "Error in SignUp");
      setLoading(false);
    }
  }

  //------- reset user password

  final TextEditingController _resetemail = TextEditingController();
  TextEditingController get resetemail => _resetemail;

  Future<void> SendResetPasswordEmail(BuildContext context) async {
    try {
      //validating inputs
      if (_resetemail.text.isNotEmpty) {
        //start creating user
        // start the loader
        setLoading(true);
        await _authController.Sendemail(
          context,
          _resetemail.text,
        ).then((value) {
          setLoading(false);

          // clear controller

          _resetemail.clear();

          setLoading(false);

          //AlertHelper.showAlert(
          //   context, "User registration success!!", "Signup Success",
          //  type: DialogType.success);
        });
      }
    } catch (e) {
      Logger().e(e);
      AlertHelper.showAlert(context, e.toString(), "Error reset");
      setLoading(false);
    }
  }

  // start page user data
  // user model object to store user object

  bool validationFieldsLogin(BuildContext context) {
    if (_loginemail.text.isEmpty || _loginpassword.text.isEmpty) {
      Logger().w("Fill all the fields");
      AlertHelper.showAlert(
          context, "Fill All text fields", "Data can't be empty");
      return false;
    } else if (!_loginemail.text.contains("@") ||
        (!_loginemail.text.contains(".com"))) {
      Logger().w("Enter valid email");
      AlertHelper.showAlert(
          context, "Email must contain @ & .com", "Invalid email");
      return false;
    } else if (_loginpassword.text.length < 8) {
      Logger().w("Enter password at least 8 characters");
      AlertHelper.showAlert(
          context, "Enter password at least 8 characters", "Invalid password");
      return false;
    } else {
      return true;
    }
  }
}
