import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/auth_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/models/user_model.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/providers/order_fetch_provider.dart';
import 'package:groceryapp/screens/main/main_screen.dart';
import 'package:groceryapp/screens/splash/auth/signup.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class UserProvider extends ChangeNotifier {
  AuthController _authController = AuthController();
  UserModel? _userModel;
  UserModel? get userModel => _userModel;
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }
//-----pick upload and update user profile img

  //image picker instence
  final ImagePicker picker = ImagePicker();

  //file object to store picked
  File _image = File("");
  //get pick file
  File get image => _image;

  // pick an img function
  Future<void> Pickimage(BuildContext context) async {
    try {
      final XFile? pickfile =
          await picker.pickImage(source: ImageSource.gallery);

      Logger().w(pickfile?.path.toString());
      if (pickfile != null) {
        _image = File(pickfile.path);
        notifyListeners();
        //start the loader
        setLoading(true);
        //start the uploading
        final imgUrl = await _authController.UploadAndUpdateProfileImg(
            _image, _userModel!.uid);
        //if url is not empty trhat means the file is uploaded success
        if (imgUrl != "") {
          //clear the file object
          _image = File("");
          //update the user model image field
          _userModel!.img = imgUrl;
          notifyListeners();
          //stop th eloader
          setLoading(false);
        } else {
          AlertHelper.showAlert(context, "Eror uploading profile img",
              "Profile image Upload Failled");
        }

        //file obect
      } else {
        Logger().e("No img selected");
      }
    } catch (e) {
// check if user has pick file or not

      Logger().e(e);
    }
  }

  Future<void> StartpageUserData(BuildContext context, String uid) async {
    try {
      await _authController.FetchUserData(context, uid).then((value) {
        if (value != null) {
          _userModel = value;
          notifyListeners();
        } else {
          AlertHelper.showAlert(
              context, "Err fetching user data", "User error");
        }
      });
    } catch (e) {
      Logger().e("${e}");
    }
  }

  Future<void> initializeUser(BuildContext context) async {
    FirebaseAuth.instance.authStateChanges().listen((User? user) async {
      if (user == null) {
        Logger().w("User signed out");
        //if the user is null send to the sign up
        Helpers.navigateTo(context, Signup());
      } else {
        await StartpageUserData(context, user.uid).then(
          (value) {
            print("User is signed in");

            // fetch products list

            Provider.of<ProductProvider>(context, listen: false)
                .StartFetchProducts();
            //fetch orders

            Provider.of<OrderFetchProvider>(context, listen: false)
                .StartFetchOrders(context);

            //send to the home
            Helpers.navigateTo(context, MainScreen());
          },
        );
      }
    });
  }
}
