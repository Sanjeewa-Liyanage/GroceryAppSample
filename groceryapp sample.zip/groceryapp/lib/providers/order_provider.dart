import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/controllers/order_controller.dart';
import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/user_model.dart';
import 'package:groceryapp/providers/auth_providers/user_provider.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/screens/main/cart/cart-widgets/bottomrow.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class OrderProvider extends ChangeNotifier {
  final OrderController _orderController = OrderController();

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  Future<void> startCreateOrder(BuildContext context) async {
    try {
      List<CartItemModel> items =
          Provider.of<cartProvider>(context, listen: false).cartitems;

      double cartTotal =
          Provider.of<cartProvider>(context, listen: false).getCartTotalPrice;

      UserModel user =
          Provider.of<UserProvider>(context, listen: false).userModel!;

      if (items.isNotEmpty) {
        setLoading(true);
        await _orderController.SaveOrder(user, cartTotal, items).then((value) {
          if (value == "Success") {
            setLoading(false);
            showDialog(
              context: context,
              builder: (context) {
                return DialogboxContent();
              },
            );
          } else {
            setLoading(false);
            AlertHelper.showAlert(context, "Error", value);
          }
        });
      } else {
        AlertHelper.showAlert(context, "Error",
            "You must add some items before placing an order");
      }
    } catch (e) {
      setLoading(false);
      Logger().e(e);
    }
  }
}
