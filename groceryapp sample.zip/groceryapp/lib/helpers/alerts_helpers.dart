import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:animated_snack_bar/animated_snack_bar.dart';

class AlertHelper {
  static void showAlert(BuildContext context, String desc, String title,
      {DialogType type = DialogType.error}) {
    AwesomeDialog(
            context: context,
            dialogType: type,
            desc: desc,
            animType: AnimType.scale,
            title: title,
            btnCancelOnPress: () {},
            btnOkOnPress: () {})
        .show();
  }

//--show a snack bar
  static void showSnackBar(BuildContext context, String msg,
      {AnimatedSnackBarType type = AnimatedSnackBarType.error}) {
    AnimatedSnackBar.material(msg,
            type: type, duration: const Duration(seconds: 1))
        .show(context);
  }
}
