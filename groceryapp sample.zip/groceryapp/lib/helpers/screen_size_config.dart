import 'package:flutter/cupertino.dart';

class SizeConfig {
  /// get screen height and width//
  ///
  ///
  ///

  static double heightofscreen(BuildContext context) =>
      MediaQuery.of(context).size.height;

  static double widthtofscreen(BuildContext context) =>
      MediaQuery.of(context).size.width;
}
