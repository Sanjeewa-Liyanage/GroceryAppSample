import 'package:flutter/material.dart';
import 'package:groceryapp/helpers/screen_size_config.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:provider/provider.dart';

class UpperSection extends StatelessWidget {
  const UpperSection({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.topLeft,
      width: SizeConfig.widthtofscreen(context),
      height: 256,
      decoration: BoxDecoration(
          color: Colors.red,
          image: DecorationImage(
              image: NetworkImage(
                  Provider.of<ProductProvider>(context).productModel.img),
              fit: BoxFit.cover)),
      child: SafeArea(child: BackButton()),
    );
  }
}
