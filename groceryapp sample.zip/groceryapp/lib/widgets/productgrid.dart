import 'package:animate_do/animate_do.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:groceryapp/providers/admin/admin_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/producttile.dart';
import 'package:provider/provider.dart';

class ProductGrid extends StatelessWidget {
  const ProductGrid({
    required this.url,
    super.key,
  });
  final String url;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FadeInLeft(child: Consumer<ProductProvider>(
        builder: (BuildContext context, value, Widget? child) {
          return value.isLoading
              ? SpinKitFoldingCube(
                  color: AppColors.primaryColor,
                  size: 80,
                )
              : value.products.isEmpty
                  ? Center(
                      child: const Customtext(
                        "No Products",
                        fontsize: 18,
                      ),
                    )
                  : GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: 0.75,
                              crossAxisSpacing: 19,
                              mainAxisSpacing: 44),
                      itemCount: value.products.length,
                      itemBuilder: (context, index) {
                        return ProductTile(
                          model: value.products[index],
                        );
                      },
                    );
        },
      )),
    );
  }
}
