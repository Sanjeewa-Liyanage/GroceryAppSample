import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/util/consts/colors.dart';

class BottomNavTile extends StatelessWidget {
  const BottomNavTile({
    super.key,
    required this.isActive,
    required this.icon,
    required this.ontap,
  });

  final bool isActive;
  final IconData icon;
  final Function() ontap;

  @override
  Widget build(BuildContext context) {
    return IconButton(
        onPressed: ontap,
        icon: Icon(icon,
            size: 38,
            color: isActive ? AppColors.primaryColor : AppColors.ash));
  }
}
