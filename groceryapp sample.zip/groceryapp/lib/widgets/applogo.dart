import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/util/consts/appassests.dart';

class applogo extends StatelessWidget {
  const applogo({
    this.height = 138,
    this.width = 202,
    super.key,
  });
  final double width;
  final double height;
  @override
  Widget build(BuildContext context) {
    return FadeInDown(
      child: Image.asset(
        Appassets.logo,
        width: width,
        height: height,
        fit: BoxFit.fill,
      ),
    );
  }
}
