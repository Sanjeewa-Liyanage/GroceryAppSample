import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:groceryapp/util/consts/colors.dart';

class Button extends StatelessWidget {
  const Button({
    this.isLoading = false,
    required this.ontap,
    required this.text,
    this.width = 159,
    this.height = 50,
    super.key,
  });
  final String text;
  final Function() ontap;
  final bool isLoading;
  final double width;
  final double height;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: isLoading ? null : ontap,
      child: Container(
        alignment: Alignment.center,
        width: width,
        height: height,
        decoration: BoxDecoration(
            color: AppColors.primaryColor,
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(color: AppColors.ash.withOpacity(0.4), blurRadius: 10)
            ]),
        child: isLoading
            ? SpinKitFoldingCube(
                color: Colors.white,
                size: 30,
              )
            : Text(
                text,
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
      ),
    );
  }
}
