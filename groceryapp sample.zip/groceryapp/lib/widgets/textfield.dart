import 'package:flutter/material.dart';
import 'package:groceryapp/util/consts/colors.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    required this.hint,
    required this.label,
    this.obs = false,
    this.controller,
    super.key,
  });
  final String hint;
  final String label;
  final bool obs;
  final TextEditingController? controller;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: AppColors.ash.withOpacity(0.3),
              offset: Offset(0, 0),
              blurRadius: 10,
            ),
          ]),
      child: TextField(
        controller: controller,
        obscureText: obs,
        decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: AppColors.ash),
            label: Text(
              label,
              style: TextStyle(
                color: AppColors.ash,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4),
              borderSide: const BorderSide(color: Colors.white),
            ),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: AppColors.primaryColor))),
      ),
    );
  }
}
