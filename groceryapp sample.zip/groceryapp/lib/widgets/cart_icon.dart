import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/screens/main/cart/cart.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:badges/badges.dart' as badges;
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class CartIcon extends StatelessWidget {
  const CartIcon({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<cartProvider>(
        builder: (BuildContext context, value, Widget? child) {
      return badges.Badge(
        badgeStyle: badges.BadgeStyle(badgeColor: AppColors.primaryColor),
        badgeContent: Customtext(
          value.cartitems.length.toString(),
          color: Colors.white,
        ),
        child: InkWell(
          child: SvgPicture.asset(Appassets.cart),
          onTap: () {
            Helpers.navigateTo(context, Cart());
          },
        ),
      );
    });
  }
}
