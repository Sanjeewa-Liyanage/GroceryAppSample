import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Customtext extends StatelessWidget {
  const Customtext(
    this.text, {
    this.color,
    this.fontWeight,
    this.fontsize,
    this.textAlign,
    this.overflow,
    super.key,
  });

  final String text;
  final double? fontsize;
  final FontWeight? fontWeight;
  final Color? color;
  final TextAlign? textAlign;
  final TextOverflow? overflow;

  @override
  Widget build(BuildContext context) {
    return Text(
      overflow: overflow,
      textAlign: TextAlign.center,
      text,
      style: GoogleFonts.poppins(
        color: color,
        fontWeight: fontWeight,
        fontSize: fontsize,
      ),
    );
  }
}
