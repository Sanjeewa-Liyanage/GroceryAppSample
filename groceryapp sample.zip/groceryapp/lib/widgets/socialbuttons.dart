import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'package:groceryapp/util/consts/colors.dart';

class socialbutton extends StatelessWidget {
  const socialbutton({
    required this.ontap,
    required this.picurl,
    super.key,
  });
  final String picurl;
  final Function() ontap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontap,
      child: Container(
          padding: EdgeInsets.symmetric(horizontal: 34, vertical: 28),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: AppColors.ash,
                    offset: Offset(0, 2),
                    blurRadius: 10.0)
              ]),
          child: SvgPicture.asset(
            picurl,
          )),
    );
  }
}
