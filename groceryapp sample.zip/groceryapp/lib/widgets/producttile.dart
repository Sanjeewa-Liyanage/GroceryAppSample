import 'package:flutter/material.dart';

import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/screens/main/productdetails/product_details.dart';
import 'package:groceryapp/util/consts/appassests.dart';

import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class ProductTile extends StatelessWidget {
  const ProductTile({
    required this.model,
    super.key,
  });
  final ProductModel model;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        //== set selected product model on click
        Provider.of<ProductProvider>(context, listen: false).setProduct = model;
        //clear the  cart counter
        Provider.of<cartProvider>(context, listen: false).clearCounter();
        //navigate to the product details screen
        Helpers.navigateTo(context, ProductDetails());
      },
      child: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: NetworkImage(model.img), fit: BoxFit.cover),
            color: Colors.brown,
            borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              margin: const EdgeInsets.all(8.0),
              padding: const EdgeInsets.all(8.0),
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: Colors.white),
              child: Consumer<ProductProvider>(
                  builder: (BuildContext context, value, Widget? child) {
                return InkWell(
                  onTap: () {
                    value.AddtoFav(model, context);
                  },
                  child: value.favProduts.contains(model)
                      ? Icon(
                          Icons.favorite,
                          color: Colors.red,
                        )
                      : Icon(
                          Icons.favorite_outline_outlined,
                          color: AppColors.ash,
                        ),
                );
              }),
            ),
            Container(
              height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.primaryColor.withOpacity(.8),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 11),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: 80,
                      child: Customtext(
                        overflow: TextOverflow.ellipsis,
                        model.productName,
                        fontsize: 15,
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Customtext(
                      "Rs .${model.price}",
                      fontsize: 12,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
