import 'package:animate_do/animate_do.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:groceryapp/admin/admin.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/providers/auth_providers/auth_provider.dart';
import 'package:groceryapp/providers/auth_providers/user_provider.dart';
import 'package:groceryapp/screens/main/account/account.dart';
import 'package:groceryapp/screens/main/account/account.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class Account extends StatefulWidget {
  const Account({super.key});

  @override
  State<Account> createState() => _AccountState();
}

class _AccountState extends State<Account> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: SafeArea(
        child: FadeInLeft(
          child: Consumer<UserProvider>(
            builder: (BuildContext context, value, Widget? child) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Customtext(
                        'Profile',
                        fontsize: 25,
                        color: AppColors.primaryColor,
                        textAlign: TextAlign.center,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 122,
                      ),
                      InkWell(
                        onTap: () => value.Pickimage(context),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(45),
                            child: value.isLoading
                                ? const SpinKitFoldingCube(
                                    color: Colors.blue,
                                    size: 30,
                                  )
                                : Image.network(
                                    value.userModel?.img ??
                                        Appassets.dumyprofile,
                                    width: 200,
                                    height: 200,
                                  )
                            // : Image.file(
                            //     value.image,
                            //     width: 200,
                            //     height: 200,
                            //   ),
                            ),
                      ),
                      SizedBox(
                        height: 18,
                      ),
                      Customtext(
                        value.userModel?.name ?? "Guest",
                        fontsize: 18,
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Customtext(
                        value.userModel?.email ?? "Guest",
                        fontsize: 13,
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Button(
                        ontap: () {
                          Provider.of<AuthProvider>(context, listen: false)
                              .Logout();
                        },
                        text: "Logout"),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Button(
                        ontap: () {
                          Helpers.navigateTo(context, Admin());
                        },
                        text: "Admin"),
                  )
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class Pickimage {}
