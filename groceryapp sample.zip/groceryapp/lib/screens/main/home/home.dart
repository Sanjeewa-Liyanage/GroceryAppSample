import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/providers/auth_providers/auth_provider.dart';
import 'package:groceryapp/screens/main/cart/cart.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/cart_icon.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/productgrid.dart';
import 'package:provider/provider.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30.0),
      child: SafeArea(
          child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                child: SvgPicture.asset(Appassets.menuicon),
                onTap: () {},
              ),
              CartIcon(),
            ],
          ),
          const SizedBox(
            height: 25,
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Customtext(
              "Vegetables",
              fontsize: 20,
              fontWeight: FontWeight.w600,
              color: AppColors.primaryColor,
            ),
          ),
          const SizedBox(
            height: 41,
          ),
          // product grid

          const ProductGrid(
            url: Appassets.dumyimg,
          )
        ],
      )),
    );
  }
}
