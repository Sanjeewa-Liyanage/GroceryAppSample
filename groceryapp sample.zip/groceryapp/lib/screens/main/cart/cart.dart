// ignore_for_file: unused_import

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/screens/main/cart/cart-widgets/bottomrow.dart';
import 'package:groceryapp/screens/main/cart/cart-widgets/carttile.dart';
import 'package:groceryapp/screens/main/productdetails/product_details.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/backbutton.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class Cart extends StatefulWidget {
  const Cart({super.key});

  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Back(),
                  Customtext(
                    'Cart',
                    fontsize: 25,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primaryColor,
                  ),
                  Icon(
                    Icons.abc,
                    color: Colors.white,
                  )
                ],
              ),
              SizedBox(
                height: 18,
              ),
              Expanded(
                child: Consumer<cartProvider>(
                    builder: (BuildContext context, value, Widget? child) {
                  return value.cartitems.isEmpty
                      ? Center(
                          child: Customtext(
                            "No tems In The Cart",
                            fontsize: 18,
                          ),
                        )
                      : ListView.separated(
                          itemBuilder: (context, index) {
                            return CartTile(
                              model: value.cartitems[index],
                            );
                          },
                          separatorBuilder: (context, index) => SizedBox(
                                height: 20,
                              ),
                          itemCount: value.cartitems.length);
                }),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomRow(),
    );
  }
}
