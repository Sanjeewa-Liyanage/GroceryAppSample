import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/order_fetch_provider.dart';
import 'package:groceryapp/providers/order_provider.dart';
import 'package:groceryapp/screens/main/Orders/orders.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class BottomRow extends StatelessWidget {
  const BottomRow({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 30),
      height: 230,
      color: Colors.white,
      child: Consumer2<cartProvider, OrderProvider>(
          builder: (context, value, order, child) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CartAmountRow(
              amount: value.getCartTotalItemCount.toString(),
              name: "Total Items",
            ),
            SizedBox(
              height: 12,
            ),
            CartAmountRow(
              amount: 'Rs -10',
              name: "Discount",
            ),
            SizedBox(
              height: 12,
            ),
            CartAmountRow(
              amount: 'Rs 20.00',
              name: "Tax",
            ),
            SizedBox(
              height: 12,
            ),
            CartAmountRow(
              isTotal: true,
              amount: 'Rs${value.getCartTotalPrice}0',
              name: "Total",
            ),
            SizedBox(
              height: 20,
            ),
            Button(
              ontap: () {
                order.startCreateOrder(context);
              },
              text: "Place Order",
              isLoading: order.isLoading,
            )
          ],
        );
      }),
    );
  }
}

class DialogboxContent extends StatelessWidget {
  const DialogboxContent({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          Container(
            height: 333,
            width: 300,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(15)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(Appassets.dialog),
                SizedBox(
                  height: 20,
                ),
                Customtext(
                  "Thanks for buying \nfrom us",
                  fontsize: 20,
                  color: AppColors.primaryColor,
                  textAlign: TextAlign.center,
                )
              ],
            ),
          ),
          Positioned(
              bottom: -25,
              child: Button(
                  ontap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Orders()),
                    );
                  },
                  text: "See your Order"))
        ],
      ),
    );
  }
}

class CartAmountRow extends StatelessWidget {
  const CartAmountRow({
    required this.amount,
    required this.name,
    this.isTotal = false,
    super.key,
  });
  final String name;
  final String amount;

  final bool isTotal;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Customtext(
          fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
          name,
          fontsize: isTotal ? 16 : 14,
        ),
        Customtext(
          fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
          amount,
          fontsize: isTotal ? 16 : 14,
        ),
      ],
    );
  }
}
