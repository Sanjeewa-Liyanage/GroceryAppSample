import 'package:flutter/material.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/cart_icon.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class CartTile extends StatelessWidget {
  const CartTile({
    required this.model,
    super.key,
  });
  final CartItemModel model;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.symmetric(horizontal: 30),
      height: 90,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.ash.withOpacity(0.3),
            offset: const Offset(0, 0),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Image.network(
              model.productModel.img,
              width: 70,
              height: 70,
              fit: BoxFit.fill,
            ),
          ),
          const SizedBox(
            width: 16,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Customtext(
                model.productModel.productName,
                fontsize: 15,
              ),
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Provider.of<cartProvider>(context, listen: false)
                            .increaseCartItemAmount(model.id);
                      },
                      icon: const Icon(Icons.add),
                      iconSize: 20),
                  const SizedBox(
                    width: 10,
                  ),
                  Customtext(
                    model.amount.toString(),
                    fontsize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  IconButton(
                    onPressed: () {
                      Provider.of<cartProvider>(context, listen: false)
                          .decreaseCartItemAmount(model.id);
                    },
                    icon: const Icon(Icons.remove),
                    iconSize: 20,
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              InkWell(
                onTap: () {
                  Provider.of<cartProvider>(context, listen: false)
                      .RemoveCartItem(model.id);
                },
                child: const Icon(
                  Icons.close,
                  color: Colors.red,
                ),
              ),
              Customtext(
                "Rs.${model.subtotal}",
                fontWeight: FontWeight.w500,
                fontsize: 15,
              )
            ],
          )
        ],
      ),
    );
  }
}
