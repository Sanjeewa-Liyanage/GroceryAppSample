import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/screens/main/Orders/orders.dart';
import 'package:groceryapp/screens/main/account/account.dart';
import 'package:groceryapp/screens/main/favourite/favourite.dart';
import 'package:groceryapp/screens/main/home/home.dart';

import 'package:groceryapp/widgets/bottom_nav_tile.dart';
import 'package:logger/logger.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _activeIndex = 0;
  void onItemTapped(int i) {
    setState(() {
      _activeIndex = i;
    });
  }

  final List<Widget> _screens = [Home(), Favourite(), Orders(), Account()];

  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 83,
        //color: AppColors.ash,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              BottomNavTile(
                icon: Icons.home,
                isActive: _activeIndex == 0,
                ontap: () {
                  onItemTapped(0);
                  Logger().i(_activeIndex);
                },
              ),
              BottomNavTile(
                icon: Icons.favorite_outline,
                isActive: _activeIndex == 1,
                ontap: () {
                  onItemTapped(1);
                  Logger().i(_activeIndex);
                },
              ),
              BottomNavTile(
                icon: Icons.menu_open,
                isActive: _activeIndex == 2,
                ontap: () {
                  onItemTapped(2);
                  Logger().i(_activeIndex);
                },
              ),
              BottomNavTile(
                icon: Icons.person,
                isActive: _activeIndex == 3,
                ontap: () {
                  onItemTapped(3);

                  Logger().i(_activeIndex);
                },
              ),
            ],
          ),
        ),
      ),
      body: _screens[_activeIndex],
    );
  }
}
