import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/providers/order_fetch_provider.dart';
import 'package:groceryapp/providers/order_provider.dart';
import 'package:groceryapp/screens/main/Orders/widgets/orders_tile.dart';
import 'package:groceryapp/screens/main/cart/cart-widgets/carttile.dart';
import 'package:groceryapp/screens/main/favourite/widgets/favourite_tile.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/backbutton.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class Orders extends StatefulWidget {
  const Orders({super.key});

  @override
  State<Orders> createState() => _OrdersState();
}

class _OrdersState extends State<Orders> {
  @override
  void initState() {
    Future.delayed(const Duration(microseconds: 10), () {
      //Helpers.navigateTo(context, Signup());
      Provider.of<OrderFetchProvider>(context, listen: false)
          .StartFetchOrders(context);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: SafeArea(
        child: Column(
          children: [
            Align(
              child: Back(),
              alignment: Alignment.centerLeft,
            ),
            Center(
              child: Customtext(
                fontWeight: FontWeight.w600,
                'Orders',
                fontsize: 25,
                color: AppColors.primaryColor,
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(
              height: 18,
            ),
            Expanded(
              child: Consumer<OrderFetchProvider>(
                  builder: (BuildContext context, value, Widget? child) {
                return value.orders.isEmpty
                    ? Center(
                        child: Customtext(
                          "No tems In The Orders",
                          fontsize: 18,
                        ),
                      )
                    : ListView.separated(
                        itemBuilder: (context, index) {
                          return OrderTile(
                            index: index,
                            model: value.orders[index],
                          );
                        },
                        separatorBuilder: (context, index) => SizedBox(
                              height: 20,
                            ),
                        itemCount: value.orders.length);
              }),
            ),
          ],
        ),
      ),
    );
  }
}
