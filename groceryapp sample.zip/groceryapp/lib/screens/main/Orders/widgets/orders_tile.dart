import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/order_model.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/cart_icon.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class OrderTile extends StatelessWidget {
  const OrderTile({
    required this.model,
    required this.index,
    super.key,
  });
  final OrderModel model;
  final int index;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.symmetric(horizontal: 30),
        height: 90,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: AppColors.ash.withOpacity(0.3),
              offset: const Offset(0, 0),
              blurRadius: 10,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                model.items.first.productModel.img,
                width: 70,
                height: 70,
                fit: BoxFit.fill,
              ),
            ),
            const SizedBox(
              width: 16,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Customtext(
                  "Quantity ${model.items.length}",
                  fontsize: 15,
                  fontWeight: FontWeight.w700,
                ),
                Customtext(
                  "Order No ${index + 1}",
                  fontsize: 15,
                ),
              ],
            ),
            const Spacer(),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Customtext(
                    "${model.orderStatus} ",
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontsize: 15,
                  ),
                ),
                Customtext(
                  "Rs.${model.total}",
                  fontWeight: FontWeight.w500,
                  fontsize: 15,
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
