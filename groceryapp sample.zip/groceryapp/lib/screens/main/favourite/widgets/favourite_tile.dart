import 'package:flutter/material.dart';
import 'package:groceryapp/models/cart_items_model.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/cart_icon.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class FavouriteTile extends StatelessWidget {
  const FavouriteTile({
    required this.model,
    super.key,
  });
  final ProductModel model;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.symmetric(horizontal: 30),
      height: 90,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.ash.withOpacity(0.3),
            offset: const Offset(0, 0),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Image.network(
              model.img,
              width: 70,
              height: 70,
              fit: BoxFit.fill,
            ),
          ),
          const SizedBox(
            width: 16,
          ),
          Customtext(
            model.productName,
            fontsize: 15,
          ),
          const Spacer(),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              InkWell(
                onTap: () {
                  Provider.of<ProductProvider>(context, listen: false)
                      .AddtoFav(model, context);
                },
                child: const Icon(
                  Icons.close,
                  color: Colors.red,
                ),
              ),
              Customtext(
                "Rs.${model.price}",
                fontWeight: FontWeight.w500,
                fontsize: 15,
              )
            ],
          )
        ],
      ),
    );
  }
}
