import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/screens/main/cart/cart-widgets/carttile.dart';
import 'package:groceryapp/screens/main/favourite/widgets/favourite_tile.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class Favourite extends StatefulWidget {
  const Favourite({super.key});

  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Center(
            child: Customtext(
              fontWeight: FontWeight.w600,
              'Favourites',
              fontsize: 25,
              color: AppColors.primaryColor,
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(
            height: 18,
          ),
          Expanded(
            child: Consumer<ProductProvider>(
                builder: (BuildContext context, value, Widget? child) {
              return value.favProduts.isEmpty
                  ? Center(
                      child: Customtext(
                        "No tems In The Favourites",
                        fontsize: 18,
                      ),
                    )
                  : ListView.separated(
                      itemBuilder: (context, index) {
                        return FavouriteTile(
                          model: value.favProduts[index],
                        );
                      },
                      separatorBuilder: (context, index) => SizedBox(
                            height: 20,
                          ),
                      itemCount: value.favProduts.length);
            }),
          ),
        ],
      ),
    );
  }
}
