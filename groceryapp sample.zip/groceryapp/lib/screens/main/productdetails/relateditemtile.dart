import 'package:flutter/material.dart';
import 'package:groceryapp/models/product_model.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/util/consts/appassests.dart';

import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class RelatedItemTile extends StatelessWidget {
  const RelatedItemTile({
    required this.model,
    super.key,
  });
  final ProductModel model;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        //clear the  cart counter
        Provider.of<cartProvider>(context, listen: false).clearCounter();
        Provider.of<ProductProvider>(context, listen: false).setProduct = model;
      },
      child: Container(
        width: 90,
        height: 90,
        alignment: Alignment.bottomCenter,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: NetworkImage(model.img), fit: BoxFit.cover),
            color: Colors.brown,
            borderRadius: BorderRadius.circular(12)),
        child: Container(
          height: 24,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: AppColors.primaryColor.withOpacity(.5),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 3),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Customtext(
                  model.productName,
                  fontsize: 11,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  width: 30,
                  child: Customtext(
                    overflow: TextOverflow.ellipsis,
                    "Rs ${model.price}",
                    fontsize: 10,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
