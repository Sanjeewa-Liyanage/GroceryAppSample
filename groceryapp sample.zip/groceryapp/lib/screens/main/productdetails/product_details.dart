import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/helpers/screen_size_config.dart';
import 'package:groceryapp/providers/home_provider/cart_provider.dart';
import 'package:groceryapp/providers/home_provider/product_provider.dart';
import 'package:groceryapp/screens/main/productdetails/relateditemtile.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/cart_icon.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/uppersection.dart';
import 'package:provider/provider.dart';

class ProductDetails extends StatefulWidget {
  const ProductDetails({super.key});

  @override
  State<ProductDetails> createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: SizeConfig.widthtofscreen(context),
        height: SizeConfig.heightofscreen(context),
        child: Stack(
          children: [
            UpperSection(),
            Positioned(
              top: 256,
              child: ProductDetailPane(),
            ),
            Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CartIcon(),
                      Consumer<ProductProvider>(
                          builder: (context, value, child) {
                        return Button(
                          width: 250,
                          ontap: () {
                            Provider.of<cartProvider>(context, listen: false)
                                .AddtoCart(value.productModel, context);
                          },
                          text: "Add to Cart",
                        );
                      }),
                    ],
                  ),
                ))
          ],
        ),
      ),
    );
  }
}

class ProductDetailPane extends StatelessWidget {
  const ProductDetailPane({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(34), topRight: Radius.circular(34))),
      height: SizeConfig.heightofscreen(context),
      width: SizeConfig.widthtofscreen(context),
      padding: const EdgeInsets.fromLTRB(29, 34, 29, 0),
      child: Consumer<ProductProvider>(builder: (context, value, child) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Customtext(
                  value.productModel.productName,
                  fontsize: 20,
                  fontWeight: FontWeight.w600,
                ),
                CounterSection(),
              ],
            ),
            SizedBox(
              height: 21,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Customtext(
                "Rs${value.productModel.price}",
                fontsize: 14,
              ),
            ),
            SizedBox(
              height: 28,
            ),
            Customtext(
              value.productModel.desc,
              textAlign: TextAlign.justify,
              fontsize: 13,
            ),
            SizedBox(
              height: 26,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Customtext(
                color: AppColors.darkgreen,
                fontWeight: FontWeight.w600,
                "Related items",
                fontsize: 14,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            SizedBox(
              height: 90,
              child: Consumer(builder: (context, watch, _) {
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return RelatedItemTile(
                      model: value.relatedproducts[index],
                    );
                  },
                  itemCount: value.relatedproducts.length,
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                    width: 10,
                  ),
                );
              }),
            ),
          ],
        );
      }),
    );
  }
}

class CounterSection extends StatelessWidget {
  const CounterSection({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      width: 130,
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
      decoration: BoxDecoration(
          border: Border.all(color: AppColors.ash),
          borderRadius: BorderRadius.circular(8)),
      child: Consumer<cartProvider>(
          builder: (BuildContext context, value, Widget? child) {
        return Row(
          children: [
            IconButton(
                onPressed: () => value.increaseCounter(),
                icon: const Icon(Icons.add),
                iconSize: 18),
            const SizedBox(
              width: 5,
            ),
            Customtext(
              '${value.counter}',
              fontsize: 13,
              fontWeight: FontWeight.w600,
            ),
            const SizedBox(
              width: 5,
            ),
            IconButton(
              onPressed: () => value.decreaseCounter(),
              icon: const Icon(Icons.remove),
              iconSize: 18,
            ),
          ],
        );
      }),
    );
  }
}
