import 'package:flutter/material.dart';

import 'package:groceryapp/helpers/alerts_helpers.dart';
import 'package:groceryapp/providers/auth_providers/auth_provider.dart';

import 'package:groceryapp/screens/splash/auth/forgotpassword.dart';
import 'package:groceryapp/util/consts/appassests.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/applogo.dart';
import 'package:groceryapp/widgets/backbutton.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/socialbuttons.dart';
import 'package:groceryapp/widgets/textfield.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';

class Signin extends StatefulWidget {
  const Signin({super.key});

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  //password text editing controller
  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Align(alignment: Alignment.topLeft, child: Back()),
                const Customtext(
                  "Login",
                  color: AppColors.primaryColor,
                  fontsize: 25,
                  fontWeight: FontWeight.bold,
                ),
                const SizedBox(
                  height: 41,
                ),
                const applogo(),
                const SizedBox(
                  height: 30,
                ),
                CustomTextField(
                  controller: Provider.of<AuthProvider>(context).loginemail,
                  hint: 'Enter your email',
                  label: "email",
                ),
                const SizedBox(
                  height: 7,
                ),
                CustomTextField(
                  controller: Provider.of<AuthProvider>(context).loginpassword,
                  hint: "Enter your Password",
                  label: "Password",
                  obs: true,
                ),
                const SizedBox(
                  height: 12.0,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Forgotpassword()));
                  },
                  child: const Align(
                    alignment: Alignment.centerRight,
                    child: Customtext("forgot your password ?"),
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                Consumer<AuthProvider>(
                  builder: (context, value, child) {
                    return Button(
                      isLoading: value.isLoading,
                      text: "SignIn",
                      ontap: () {
                        value.startLogin(context);
                      },
                    );
                  },
                ),
                const SizedBox(
                  height: 23,
                ),
                const Customtext(
                  "or login with your social accounts",
                  fontsize: 14,
                ),
                const SizedBox(
                  height: 12,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    socialbutton(
                      picurl: Appassets.google,
                      ontap: () {},
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    socialbutton(
                      picurl: Appassets.fb,
                      ontap: () {},
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
