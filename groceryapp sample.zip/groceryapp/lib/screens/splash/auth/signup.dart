import 'package:flutter/material.dart';
import 'package:groceryapp/screens/splash/auth/signin.dart';
import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/applogo.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/textfield.dart';
import 'package:provider/provider.dart';
import 'package:groceryapp/providers/auth_providers/auth_provider.dart';

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Customtext(
                    "SignUp",
                    color: AppColors.primaryColor,
                    fontsize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                  const SizedBox(
                    height: 41,
                  ),
                  const applogo(),
                  const SizedBox(
                    height: 30,
                  ),
                  CustomTextField(
                    hint: 'Enter username',
                    label: "Name",
                    controller: Provider.of<AuthProvider>(context).username,
                  ),
                  const SizedBox(
                    height: 7,
                  ),
                  CustomTextField(
                    hint: "Enter Your email",
                    label: "email",
                    controller: Provider.of<AuthProvider>(context).email,
                  ),
                  const SizedBox(
                    height: 7,
                  ),
                  CustomTextField(
                    hint: "Enter your Password",
                    label: "Password",
                    obs: true,
                    controller: Provider.of<AuthProvider>(context).password,
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Signin(),
                        ),
                      );
                    },
                    child: const Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        "Already have an account",
                        style: TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  Consumer<AuthProvider>(
                    builder: (context, value, child) {
                      return Button(
                        isLoading: value.isLoading,
                        text: "Signup",
                        ontap: () {
                          value.startSignup(context);
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
