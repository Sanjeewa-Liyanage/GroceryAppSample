import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:groceryapp/providers/auth_providers/auth_provider.dart';

import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/applogo.dart';
import 'package:groceryapp/widgets/backbutton.dart';
import 'package:groceryapp/widgets/button.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:groceryapp/widgets/textfield.dart';
import 'package:provider/provider.dart';

class Forgotpassword extends StatefulWidget {
  const Forgotpassword({super.key});

  @override
  State<Forgotpassword> createState() => _ForgotpasswordState();
}

class _ForgotpasswordState extends State<Forgotpassword> {
  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            // ignore: prefer_const_constructors
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Align(alignment: Alignment.topLeft, child: Back()),
                const Customtext(
                  "Forgot Password",
                  color: AppColors.primaryColor,
                  fontsize: 25,
                  fontWeight: FontWeight.bold,
                ),
                const SizedBox(
                  height: 41,
                ),
                const applogo(),
                const SizedBox(
                  height: 100,
                ),
                const Customtext(
                  "Please, enter your email address. You will recieve a link to create a new password via email",
                  fontsize: 14,
                ),
                const SizedBox(
                  height: 16,
                ),
                CustomTextField(
                  controller: Provider.of<AuthProvider>(context).resetemail,
                  hint: "Enter Your email",
                  label: "email",
                ),
                const SizedBox(
                  height: 12,
                ),
                const SizedBox(
                  height: 24,
                ),
                Consumer<AuthProvider>(
                  builder: (context, value, child) {
                    return Button(
                      isLoading: value.isLoading,
                      text: "Forgot password",
                      ontap: () {
                        value.SendResetPasswordEmail(context);
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
