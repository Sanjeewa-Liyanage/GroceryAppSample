import 'package:animate_do/animate_do.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:groceryapp/helpers/helper.dart';
import 'package:groceryapp/providers/auth_providers/user_provider.dart';

import 'package:groceryapp/screens/splash/auth/signup.dart';

import 'package:groceryapp/util/consts/colors.dart';
import 'package:groceryapp/widgets/applogo.dart';
import 'package:groceryapp/widgets/customtext.dart';
import 'package:provider/provider.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    Future.delayed(const Duration(seconds: 2), () {
      //Helpers.navigateTo(context, Signup());
      Provider.of<UserProvider>(context, listen: false).initializeUser(context);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const applogo(
            width: 331,
            height: 255,
          ),
          const SizedBox(
            height: 72,
          ),
          FadeInUp(
            child: Customtext(
              "Shop Your Daily \nNeccesory",
              fontsize: 30,
              color: AppColors.primaryColor,
              fontWeight: FontWeight.w500,
            ),
          )
        ],
      )),
    );
  }
}
